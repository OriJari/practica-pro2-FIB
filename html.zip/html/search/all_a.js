var searchData=
[
  ['obte_5ffi',['obte_fi',['../class_arbre.html#a3a58581e952cb82c59cdd49563baf236',1,'Arbre']]],
  ['obte_5fini',['obte_ini',['../class_arbre.html#a7d0f783bba3cb94884993c39bf3e2591',1,'Arbre']]],
  ['obte_5ftag',['obte_tag',['../class_arbre.html#a207033dcd40534430b0f0fb8a3c8e10f',1,'Arbre']]],
  ['obte_5ftipus',['obte_tipus',['../class_arbre.html#ae994bd32887eb8906e34211a220bb2a9',1,'Arbre']]],
  ['obten_5falbum',['obten_album',['../class_coleccio.html#a20d1641ef7838f5f8e7a9203bd56f38b',1,'Coleccio']]],
  ['obten_5ffoto',['obten_foto',['../class_album__en__curs.html#aaf2e2fc589cdbfd71d8566b13f0be98c',1,'Album_en_curs']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../_arbre_8cc.html#ae1cab2088858cc079282d35e66f3236c',1,'operator&gt;&gt;(istream &amp;is, Arbre &amp;q):&#160;Arbre.cc'],['../_arbre_8hh.html#ae1cab2088858cc079282d35e66f3236c',1,'operator&gt;&gt;(istream &amp;is, Arbre &amp;q):&#160;Arbre.cc']]],
  ['or',['OR',['../class_arbre.html#ae31e8ce735deb23dd0835f99e02c7697',1,'Arbre']]]
];
