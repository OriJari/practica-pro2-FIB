var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modifica_5ffoto',['modifica_foto',['../class_coleccio.html#af57be9c2e2ec0e74dfdcc725651cfbd7',1,'Coleccio']]],
  ['modificar_5ffoto',['modificar_foto',['../class_album__en__curs.html#ac1ec57d3ad0c157fa724451687f6cfca',1,'Album_en_curs']]]
];
