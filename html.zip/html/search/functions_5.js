var searchData=
[
  ['id_5ffoto',['id_foto',['../class_fotografia.html#a64badc3aa923be7d12bdeb3368ad5f0e',1,'Fotografia']]],
  ['ida_5falbum',['ida_album',['../class_album__en__curs.html#a3b5f2b18e83632baf74568c0a71aeeff',1,'Album_en_curs']]],
  ['imprime_5falbum',['imprime_album',['../class_album__en__curs.html#a834b29ad389dd65999a1643bc2e1c350',1,'Album_en_curs']]],
  ['imprime_5fcoleccion',['imprime_coleccion',['../class_coleccio.html#ab65d1a6b02c478c1646fdf025fd773fe',1,'Coleccio']]],
  ['imprime_5ffoto',['imprime_foto',['../class_fotografia.html#a73c43dea9f6dd5e37d240f72de26f7ea',1,'Fotografia']]],
  ['iniciar',['iniciar',['../class_album__en__curs.html#a4e69949bc144b919dbc90b2aeb19cef9',1,'Album_en_curs']]],
  ['interseccio_5falbum',['interseccio_album',['../class_album__en__curs.html#a10645aef25519a401b795955fde3eaaa',1,'Album_en_curs']]]
];
