var searchData=
[
  ['afegir_5ffoto_5fa_5fall',['afegir_foto_a_ALL',['../class_coleccio.html#a17a96a70062dbe8d6d24b60cfd5b3044',1,'Coleccio']]],
  ['agrega_5falbum',['agrega_album',['../class_coleccio.html#a5547662f5ae2cb47b30a182cc231b024',1,'Coleccio']]],
  ['agrega_5ffoto',['agrega_foto',['../class_album__en__curs.html#a32595bedd141446be1d3e19d2b1e943c',1,'Album_en_curs::agrega_foto()'],['../class_coleccio.html#a7a7c30e1f8feffcedc0cc73306cea3fc',1,'Coleccio::agrega_foto()']]],
  ['agrega_5ffoto_5fobj',['agrega_foto_obj',['../class_album__en__curs.html#ad03b62124e32b82c09f5d0b56cfc3c03',1,'Album_en_curs']]],
  ['agregar_5fetiqueta',['agregar_etiqueta',['../class_fotografia.html#a70e0c490f2605b2901d5d7658726d4d2',1,'Fotografia']]],
  ['album_5fen_5fcurs',['Album_en_curs',['../class_album__en__curs.html#abdff7315af0f39e062862f01770e2f6a',1,'Album_en_curs']]],
  ['and',['AND',['../class_arbre.html#a0a62b129dd68795b16db2fb21287e7d7',1,'Arbre']]],
  ['arbre',['Arbre',['../class_arbre.html#a761f4a2c6a43f44b38d4ac6fc1cf5cae',1,'Arbre::Arbre()'],['../class_arbre.html#a860ce63ba330ecc766cbdb215bb1f4fc',1,'Arbre::Arbre(const string &amp;s)'],['../class_arbre.html#a38ea934090f2417e62f3b85b262c6944',1,'Arbre::Arbre(const data &amp;inici, const data &amp;fi)']]],
  ['avanzar',['avanzar',['../class_album__en__curs.html#a76b05654c617c7e320f7aea952c45219',1,'Album_en_curs']]]
];
