var searchData=
[
  ['rangdata',['rangdata',['../class_fotografia.html#ac58ace54d22125fa4602b1abeb08d125',1,'Fotografia']]],
  ['read',['read',['../class_arbre.html#aef244c418bdd782e8a006d16bcf78560',1,'Arbre']]],
  ['read_5finput',['read_input',['../class_arbre.html#a01d6757b27b23f7a2821e2b1c0d28e42',1,'Arbre']]],
  ['recursio',['recursio',['../class_coleccio.html#af88a8dac094e877a24c3e6f62a9d3d87',1,'Coleccio']]],
  ['right',['right',['../class_arbre.html#a498b1839f9f68d983e6f84486ffc8f4b',1,'Arbre']]]
];
