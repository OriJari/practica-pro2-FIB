var searchData=
[
  ['fotos',['fotos',['../class_album__en__curs.html#a8638a4a3e8baa38000c9f67d1b396bda',1,'Album_en_curs::fotos()'],['../class_coleccio.html#a34ab6788b90f99589806cfc3a16c8c1a',1,'Coleccio::fotos()']]]
];
