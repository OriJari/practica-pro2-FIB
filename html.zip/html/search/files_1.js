var searchData=
[
  ['coleccio_2ecc',['Coleccio.cc',['../_coleccio_8cc.html',1,'']]],
  ['coleccio_2ehh',['Coleccio.hh',['../_coleccio_8hh.html',1,'']]]
];
