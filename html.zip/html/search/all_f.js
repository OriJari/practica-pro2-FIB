var searchData=
[
  ['_7ealbum_5fen_5fcurs',['~Album_en_curs',['../class_album__en__curs.html#a2faeed862407778988243456b071d3d6',1,'Album_en_curs']]],
  ['_7earbre',['~Arbre',['../class_arbre.html#ad5f22ec66953891aef2722438fb7c088',1,'Arbre']]],
  ['_7ecoleccio',['~Coleccio',['../class_coleccio.html#a0289eaa5e9e418b8bb9329f0db3ef05c',1,'Coleccio']]],
  ['_7efotografia',['~Fotografia',['../class_fotografia.html#a0dc7cfd4c99fc6527b156f0e27cafb55',1,'Fotografia']]]
];
