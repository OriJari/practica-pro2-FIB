var searchData=
[
  ['fotografia',['Fotografia',['../class_fotografia.html',1,'']]]
];
