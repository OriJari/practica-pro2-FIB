var searchData=
[
  ['fecha_5ftoma',['fecha_toma',['../class_fotografia.html#abef84dc788a97d02ae28aec482d82c65',1,'Fotografia']]],
  ['foto_5factual',['foto_actual',['../class_album__en__curs.html#a4711916b0f360b508ef4fac2dea387b9',1,'Album_en_curs']]],
  ['fotografia',['Fotografia',['../class_fotografia.html#a3337ed5e5fa3917a560fbd3ecacaa51b',1,'Fotografia']]]
];
