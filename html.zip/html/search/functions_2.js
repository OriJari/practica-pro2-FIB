var searchData=
[
  ['cambiar_5fid',['cambiar_id',['../class_album__en__curs.html#a407f133f8c2e7fe2051de0fe98e9dcfe',1,'Album_en_curs']]],
  ['clear',['clear',['../class_album__en__curs.html#aba7bc96cc18ee4fb3a29cde2fb7ff815',1,'Album_en_curs']]],
  ['coleccio',['Coleccio',['../class_coleccio.html#a44e24b7beff8ba103c196e9a0a5ee736',1,'Coleccio']]],
  ['comp_5fdata',['comp_data',['../class_fotografia.html#ab86fec02f36c7d06978f9243084b38ba',1,'Fotografia']]],
  ['complementari_5falbum',['complementari_album',['../class_album__en__curs.html#a4fc3a741d2b2b08650ec6441ba838407',1,'Album_en_curs']]],
  ['construct_5fbool_5fquery',['construct_bool_query',['../_arbre_8cc.html#a628cb3df8af297e13d4a96004f01eb97',1,'Arbre.cc']]],
  ['contiene_5falbum',['contiene_album',['../class_coleccio.html#a6e83287b55423d1233fba99003145bc8',1,'Coleccio']]],
  ['contiene_5fetiqueta',['contiene_etiqueta',['../class_fotografia.html#a404c0b1c74b9b282e0c75953ced23b88',1,'Fotografia']]],
  ['convert_5finfix_5fto_5fpostfix',['convert_infix_to_postfix',['../_arbre_8cc.html#a124c96f1fed1427137c2feddbe20d4bb',1,'Arbre.cc']]],
  ['crear_5ffoto',['crear_foto',['../class_fotografia.html#a803ad540949a9e7a34affac13bdfab72',1,'Fotografia']]]
];
