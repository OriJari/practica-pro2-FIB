var searchData=
[
  ['busca_5fpor_5fetiqueta',['busca_por_etiqueta',['../class_coleccio.html#ab777d3b046b1233fda53bed6d82eb87d',1,'Coleccio']]],
  ['busca_5fpor_5ffecha',['busca_por_fecha',['../class_coleccio.html#a6124eda9bfbea440e741628ec24ded57',1,'Coleccio']]]
];
