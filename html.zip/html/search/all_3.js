var searchData=
[
  ['data_5ffoto',['data_foto',['../class_fotografia.html#acbd0d0ad23d6d7887ffc3e3ec8d35807',1,'Fotografia']]]
];
