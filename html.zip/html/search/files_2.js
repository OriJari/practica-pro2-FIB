var searchData=
[
  ['fotografia_2ecc',['Fotografia.cc',['../_fotografia_8cc.html',1,'']]],
  ['fotografia_2ehh',['Fotografia.hh',['../_fotografia_8hh.html',1,'']]]
];
