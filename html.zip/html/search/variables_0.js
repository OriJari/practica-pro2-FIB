var searchData=
[
  ['albums',['albums',['../class_coleccio.html#af9c58b34934c558b64490736890b81ee',1,'Coleccio']]]
];
