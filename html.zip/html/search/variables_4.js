var searchData=
[
  ['id',['id',['../class_fotografia.html#a3bf349709deb984ba80f40791a3c04f7',1,'Fotografia']]],
  ['ida',['ida',['../class_album__en__curs.html#aba0fc6c628e05a21b9b117e8c402555b',1,'Album_en_curs']]],
  ['it',['It',['../class_album__en__curs.html#ae159142a7f3a01d370704bd486825941',1,'Album_en_curs']]]
];
