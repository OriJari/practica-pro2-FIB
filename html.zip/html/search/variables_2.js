var searchData=
[
  ['etiquetes',['etiquetes',['../class_fotografia.html#a00112c71d4c706f0b6b4b55b23f95453',1,'Fotografia']]]
];
