var searchData=
[
  ['fecha_5ftoma',['fecha_toma',['../class_fotografia.html#abef84dc788a97d02ae28aec482d82c65',1,'Fotografia']]],
  ['foto_5factual',['foto_actual',['../class_album__en__curs.html#a4711916b0f360b508ef4fac2dea387b9',1,'Album_en_curs']]],
  ['fotografia',['Fotografia',['../class_fotografia.html',1,'Fotografia'],['../class_fotografia.html#a3337ed5e5fa3917a560fbd3ecacaa51b',1,'Fotografia::Fotografia()']]],
  ['fotografia_2ecc',['Fotografia.cc',['../_fotografia_8cc.html',1,'']]],
  ['fotografia_2ehh',['Fotografia.hh',['../_fotografia_8hh.html',1,'']]],
  ['fotos',['fotos',['../class_album__en__curs.html#a8638a4a3e8baa38000c9f67d1b396bda',1,'Album_en_curs::fotos()'],['../class_coleccio.html#a34ab6788b90f99589806cfc3a16c8c1a',1,'Coleccio::fotos()']]]
];
