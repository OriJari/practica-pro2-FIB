var searchData=
[
  ['lee_5falbum',['lee_album',['../class_album__en__curs.html#a8ae0800a4b3c67693efd11560c00199c',1,'Album_en_curs']]],
  ['leer_5ffoto',['leer_foto',['../class_fotografia.html#a9925c859a8c27d7f023a8d1f9a2adad7',1,'Fotografia']]],
  ['left',['left',['../class_arbre.html#a9a094d53d7c1f8fcb707cf6a25376ebe',1,'Arbre']]],
  ['lista_5falbumes',['lista_albumes',['../class_coleccio.html#aac8e8b1b08c217dd225c14e11c63ba85',1,'Coleccio']]],
  ['lista_5falbumes_5ffoto',['lista_albumes_foto',['../class_coleccio.html#a6619605902188c7f7d97e264053a207c',1,'Coleccio']]]
];
