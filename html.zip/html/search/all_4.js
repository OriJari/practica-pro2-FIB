var searchData=
[
  ['elimina_5falbum',['elimina_album',['../class_coleccio.html#a4ba45e33ee866b71aebb447f4a176869',1,'Coleccio']]],
  ['elimina_5fetiqueta',['elimina_etiqueta',['../class_fotografia.html#a7d321ed80ef3ca58f5ad4d11a9f63ae0',1,'Fotografia']]],
  ['elimina_5ffoto',['elimina_foto',['../class_album__en__curs.html#ad93b62226cc511556947b1ca5dd4ed9e',1,'Album_en_curs::elimina_foto()'],['../class_coleccio.html#a758ea4d47da954a23748c079d400978d',1,'Coleccio::elimina_foto()']]],
  ['empty',['empty',['../class_arbre.html#a7e23c5fb57101a355e1d657186463dfc',1,'Arbre']]],
  ['es_5ffulla',['es_fulla',['../class_arbre.html#a0c7abe4691effec4f6a7b060834e122d',1,'Arbre']]],
  ['es_5fultima',['es_ultima',['../class_album__en__curs.html#ab361527802603b5c70bc4146545d6b73',1,'Album_en_curs']]],
  ['etiquetes',['etiquetes',['../class_fotografia.html#a00112c71d4c706f0b6b4b55b23f95453',1,'Fotografia']]],
  ['evalua_5fconsulta_5fbooleana',['evalua_consulta_booleana',['../class_coleccio.html#a5bb4dac752fd587a1eb10275043cd116',1,'Coleccio']]]
];
