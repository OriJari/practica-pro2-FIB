var searchData=
[
  ['not',['NOT',['../class_arbre.html#a628de7ef027b6cf209cd74312f72c75c',1,'Arbre']]],
  ['nr_5falbumes',['nr_albumes',['../class_coleccio.html#a8d5138ffe8d7ad93f4f4eedf8d34c52f',1,'Coleccio']]],
  ['nr_5falbumes_5ffoto',['nr_albumes_foto',['../class_coleccio.html#ad6e6cf5ac6b8589a507c7bdeb411430e',1,'Coleccio']]],
  ['nr_5fetiquetas',['nr_etiquetas',['../class_fotografia.html#ae060c871f2a5a712785fa245213267ac',1,'Fotografia']]],
  ['nr_5ffoto',['nr_foto',['../class_album__en__curs.html#a0f80a5fc7329c1e04fef2664b49340db',1,'Album_en_curs']]]
];
